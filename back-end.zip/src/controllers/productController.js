import db from "../config/db.js";
import multer from "multer";
import path from "path";

// ==================== KONFIGURASI MULTER ====================
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // folder tempat nyimpan gambar
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + path.extname(file.originalname);
    cb(null, uniqueName);
  },
});

export const upload = multer({ storage });

// ==================== GET ALL PRODUCTS ====================
export const getAllProducts = async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM produk");
    res.json(rows);
  } catch (err) {
    console.error("❌ Error fetching produk:", err);
    res.status(500).json({ message: "Gagal mengambil data produk" });
  }
};

// ==================== GET PRODUCT BY ID ====================
export const getProductById = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.query("SELECT * FROM produk WHERE id_produk = ?", [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: "Produk tidak ditemukan" });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error("❌ Error fetching produk by ID:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// ==================== ADD NEW PRODUCT (DENGAN GAMBAR) ====================
export const addProduct = async (req, res) => {
  const { nama_produk, model, warna, ukuran, variasi, bahan, } = req.body;
  const gambar = req.file ? req.file.filename : null;

  // Validasi input
  if (!nama_produk || !model || !warna || !ukuran || !variasi || !bahan || !gambar) {
    return res.status(400).json({ message: "Semua field harus diisi" });
  }

  try {
    const sql = `
      INSERT INTO produk (nama_produk, model, warna, ukuran, variasi, bahan, gambar)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    await db.query(sql, [nama_produk, model, warna, ukuran, variasi, bahan, gambar]);
    res.status(201).json({ message: "Produk berhasil ditambahkan" });
  } catch (error) {
    console.error("❌ Error menambahkan produk:", error);
    res.status(500).json({ message: "Gagal menambahkan produk" });
  }
};

// ==================== DELETE PRODUCT ====================
export const deleteProduct = async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await db.query("DELETE FROM produk WHERE id_produk = ?", [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Produk tidak ditemukan" });
    }

    res.json({ message: "Produk berhasil dihapus" });
  } catch (error) {
    console.error("❌ Error menghapus produk:", error);
    res.status(500).json({ message: "Gagal menghapus produk" });
  }
};
