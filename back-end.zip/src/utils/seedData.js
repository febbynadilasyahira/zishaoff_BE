export const seedProducts = async () => {
  console.log('✅ Dummy data produk berhasil dimasukkan');
};
